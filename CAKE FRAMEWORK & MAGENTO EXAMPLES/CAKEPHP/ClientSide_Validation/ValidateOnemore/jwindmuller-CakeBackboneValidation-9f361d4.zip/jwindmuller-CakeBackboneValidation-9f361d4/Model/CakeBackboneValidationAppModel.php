<?php

class CakeBackboneValidationAppModel extends AppModel {

}

