<?php
class JsValidateAppModel extends AppModel {
 
}
?>