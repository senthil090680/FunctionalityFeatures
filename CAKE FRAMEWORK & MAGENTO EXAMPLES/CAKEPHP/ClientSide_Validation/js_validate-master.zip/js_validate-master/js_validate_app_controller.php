<?php
class JsValidateAppController extends AppController {

}

?>